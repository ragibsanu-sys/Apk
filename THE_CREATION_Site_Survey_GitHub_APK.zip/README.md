# THE CREATION — Site Survey Android App (GitHub APK Builder)

यह प्रोजेक्ट **THE CREATION Site Survey** वेब टूल को एक असली Android `.apk` ऐप में बदलने के लिए तैयार किया गया है (Capacitor + GitHub Actions)।

## GitHub से `.apk` कैसे बनाएँ (आसान स्टेप्स)

1. इस ZIP को अपने कंप्यूटर या फोन में **Unzip (Extract)** करें।
2. [GitHub.com](https://github.com) पर एक **नया Repository** बनाएँ (उदाहरण: `the-creation-site-survey`)।
3. Extract किए गए सभी फ़ाइल और फ़ोल्डर (ध्यान रहे `.github` फ़ोल्डर भी शामिल हो) उस Repository में **Upload / Push** करें।
4. Repository के **Actions** टैब में जाएँ:
   - वहाँ **Build Android APK** नाम का workflow अपने-आप चलने लगेगा (या आप **Run workflow** बटन दबाकर भी चला सकते हैं)।
5. लगभग 3–5 मिनट में बिल्ड पूरा हो जाएगा।
6. बिल्ड पर क्लिक करें और नीचे **Artifacts** सेक्शन से **`THE-CREATION-Site-Survey-APK`** डाउनलोड करें।
7. डाउनलोड की गई ZIP के अंदर **`THE-CREATION-Site-Survey.apk`** मिलेगा — इसे अपने Android फोन में इंस्टॉल करें।

## ऐप की खासियतें (Android के लिए अपडेटेड)
- **Offline Support**: `exif-js` और `jsPDF` बिल्ड के समय ऐप के अंदर बंडल हो जाते हैं।
- **Native PDF Save & Share**: "Generate PDF Report" दबाने पर PDF सीधे Android में सेव और Share (WhatsApp, Files, Drive, Email) होता है।
- **Camera & GPS Permissions**: पहली बार खोलने पर Camera, Location और Storage की परमिशन माँगता है। अगर फोटो में EXIF GPS न हो तो फोन की लाइव Location से GPS स्टैम्प करने का बैकअप भी है।
